<?php $__env->startSection('content'); ?>
        <!-- Konten admin panel -->
        <div class="container-head">
            <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>

        </div>
        <!-- Tempatkan konten admin di sini -->


        <div class="container">
            <h1>Info Pendaftaran</h1>
            <table>
                <thead>
                    <tr>
                        <th>Nama Instansi</th>
                        <th>Alamat</th>
                        <th>Link Pendaftaran</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $info_pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i->name); ?></td>
                            <td><?php echo e($i->address); ?></td>
                            <td><?php echo e($i->link); ?></td>
                            <td>
                                <a href="/controlpanel/admin/info-pendaftaran/edit/<?php echo e($i->id); ?>" class="edit-button"><button>Edit</button></a>
                                <a href="/controlpanel/admin/info-pendaftaran/hapus/<?php echo e($i->id); ?>" class="delete-button"><button>Hapus</button></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="add-news-button">
                <a href="/controlpanel/admin/info-pendaftaran/tambah"><button>Tambah Info Pendaftaran</button></a>
            </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/adminInfoPendaftaran.blade.php ENDPATH**/ ?>