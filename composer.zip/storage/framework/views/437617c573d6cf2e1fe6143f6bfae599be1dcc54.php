<?php $__env->startSection('content'); ?>
    <div class="container-head">
        <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>

    </div>
    <!-- Tempatkan konten admin di sini -->


    <div class="container">

        <!-- Form tambah berita -->
        <div class="container-form">


            <?php if(isset($berita)): ?>
                <h1>EDIT BERITA</h1>
                <form action="/admin/berita/edit/<?php echo e($berita->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="judul">Judul:</label>
                        <input type="text" id="judul" name="judul" value="<?php echo e($berita->title); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="author">Author:</label>
                        <input type="text" id="author" name="author" value="<?php echo e($berita->author); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Tanggal:</label>
                        <input type="date" id="tanggal" name="tanggal" value="<?php echo e($berita->date); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="isi">Isi Berita:</label>
                        <textarea id="editor" name="isi"><?php echo e($berita->content); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="foto">Foto:</label>
                        <input type="file" id="foto" name="foto" accept="image/*">
                    </div>

                    <div class="add-news-button">
                        <button type="submit">Edit Berita</button>
                    </div>


                </form>
            <?php else: ?>
                <h1>TAMBAH BERITA</h1>

                <form action="/admin/berita" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="judul">Judul:</label>
                        <input type="text" id="judul" name="judul" required>
                    </div>
                    <div class="form-group">
                        <label for="author">Author:</label>
                        <input type="text" id="author" name="author" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Tanggal:</label>
                        <input type="date" id="tanggal" name="tanggal" required>
                    </div>
                    <div class="form-group">
                        <label for="isi">Isi Berita:</label>
                        <textarea id="editor" name="isi"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="foto">Foto:</label>
                        <input type="file" id="foto" name="foto" accept="image/*" required>
                    </div>

                    <div class="add-news-button">
                        <button type="submit">Tambah Berita</button>
                    </div>

                </form>
            <?php endif; ?>
        </div>

    </div>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.2.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor

            .create(document.querySelector('#editor'), {
                removePlugins: ['CKFinderUploadAdapter', 'CKFinder', 'EasyImage', 'Image', 'ImageCaption', 'ImageStyle',
                    'ImageToolbar', 'ImageUpload', 'MediaEmbed'
                ],
            })
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/tambahBerita.blade.php ENDPATH**/ ?>