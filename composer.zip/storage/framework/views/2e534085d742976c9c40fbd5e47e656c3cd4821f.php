<?php $__env->startSection('content'); ?>

<div class="container-head">
    <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>

</div>
<!-- Tempatkan konten admin di sini -->


<div class="container">
    <h1>Data Pengasuh</h1>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Keterangan</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pengasuh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><img style="width: 100px; height: auto;" src="<?php echo e(asset('images/pengasuh/' . $p->image)); ?>"
                            alt="image"></td>
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo e($p->position); ?></td>
                    <td><?php echo substr($p->description, 0, 100); ?>...</td>
                    <td>
                        <a href="/controlpanel/admin/pengasuh/edit/<?php echo e($p->id); ?>" class="edit-button"><button>Edit</button></a>
                        <a href="/controlpanel/admin/pengasuh/hapus/<?php echo e($p->id); ?>" class="delete-button"><button>Hapus</button></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="add-news-button">
        <a href="/controlpanel/admin/pengasuh/tambah"><button>Tambah Pengasuh</button></a>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/adminPengasuh.blade.php ENDPATH**/ ?>