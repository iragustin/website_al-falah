<?php $__env->startSection('content'); ?>
    <div class="container-head">
        <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>


    </div>

    <div class="container">
        <div class="container-form">
            <?php if(isset($pendaftar)): ?>
                <h1>EDIT PENDAFTAR</h1>
                <form action="/admin/pendaftar/edit/<?php echo e($pendaftar->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Nama:</label>
                        <input type="text" id="name" name="name" value="<?php echo e($pendaftar->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Jenis Kelamin:</label>
                        <select id="gender" name="gender" required value="<?php echo e($pendaftar->gender); ?>">
                            <option value="" selected>Pilih</option>
                            <option value="laki-laki">Laki-laki</option>
                            <option value="perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="birth_place">Tempat Lahir:</label>
                        <input type="text" id="birth_place" name="birth_place" value="<?php echo e($pendaftar->birth_place); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="birth_date">Tanggal Lahir:</label>
                        <input type="date" id="birth_date" name="birth_date" value="<?php echo e($pendaftar->birth_date); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Nomor Telepon:</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo e($pendaftar->phone); ?>" pattern="[0-9]{9,}" required>
                        <small style="color:#cccccc">Contoh: 081234567890</small>
                    </div>
                    <div class="form-group">
                        <label for="mother_name">Nama Ibu:</label>
                        <input type="text" id="mother_name" name="mother_name" value="<?php echo e($pendaftar->mother_name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="father_name">Nama Ayah:</label>
                        <input type="text" id="father_name" name="father_name" value="<?php echo e($pendaftar->father_name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="parent_phone">Nomor Telepon Wali:</label>
                        <input type="tel" id="parent_phone" name="parent_phone" value="<?php echo e($pendaftar->parent_phone); ?>" pattern="[0-9]{9,}" required>
                        <small style="color:#cccccc">Contoh: 081234567890</small>
                    </div>
                    <div class="form-group">
                        <label for="email">E-Mail:</label>
                        <input type="text" id="email" name="email" value="<?php echo e($pendaftar->email); ?>" required>
                        <small style="color:#cccccc">Catatan : Alamat E-mail aktif!</small>
                    </div>
                    <div class="form-group">
                        <label for="address">Alamat:</label>
                        <textarea id="address" name="address" required cols="50" rows="10"><?php echo e($pendaftar->address); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="school_origin">Asal Sekolah:</label>
                        <input type="text" id="school_origin" name="school_origin" value="<?php echo e($pendaftar->school_origin); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="type">Jenis Pendaftaran:</label>
                        <select id="type" name="type" required value="<?php echo e($pendaftar->type); ?>">
                            <option value="" selected>Pilih</option>
                            <option value="takhosus">Takhosus</option>
                            <option value="tahfidz">Tahfidz</option>
                        </select>
                    </div>
                    <div class="add-news-button">
                        <button type="submit">Edit Pendaftar</button>
                    </div>
                </form>
            <?php else: ?>
                <h1>TAMBAH PENDAFTAR</h1>
                <form action="/pendaftaran" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Nama:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Jenis Kelamin:</label>
                        <select id="gender" name="gender" required>
                            <option value="" selected>Pilih</option>
                            <option value="laki-laki">Laki-laki</option>
                            <option value="perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="birth_place">Tempat Lahir:</label>
                        <input type="text" id="birth_place" name="birth_place" required>
                    </div>
                    <div class="form-group">
                        <label for="birth_date">Tanggal Lahir:</label>
                        <input type="date" id="birth_date" name="birth_date" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Nomor Telepon:</label>
                        <input type="tel" id="phone" name="phone" pattern="[0-9]{9,}" required>
                        <small style="color:#cccccc">Contoh: 081234567890</small>
                    </div>
                    <div class="form-group">
                        <label for="mother_name">Nama Ibu:</label>
                        <input type="text" id="mother_name" name="mother_name" required>
                    </div>
                    <div class="form-group">
                        <label for="father_name">Nama Ayah:</label>
                        <input type="text" id="father_name" name="father_name" required>
                    </div>
                    <div class="form-group">
                        <label for="parent_phone">Nomor Telepon Wali:</label>
                        <input type="tel" id="parent_phone" name="parent_phone" pattern="[0-9]{9,}" required>
                        <small style="color:#cccccc">Contoh: 081234567890</small>
                    </div>
                    <div class="form-group">
                        <label for="email">E-Mail:</label>
                        <input type="text" id="email" name="email" required>
                        <small style="color:#cccccc">Catatan : Alamat E-mail aktif!</small>
                    </div>
                    <div class="form-group">
                        <label for="address">Alamat:</label>
                        <textarea id="address" name="address" required cols="50" rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="school_origin">Asal Sekolah:</label>
                        <input type="text" id="school_origin" name="school_origin" required>
                    </div>
                    <div class="form-group">
                        <label for="type">Jenis Pendaftaran:</label>
                        <select id="type" name="type" required>
                            <option value="" selected>Pilih</option>
                            <option value="takhosus">Takhosus</option>
                            <option value="tahfidz">Tahfidz</option>
                        </select>
                    </div>
                    <div class="add-news-button">
                        <button type="submit">Tambah Pendaftar</button>
                    </div>

                </form>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/tambahPendaftar.blade.php ENDPATH**/ ?>