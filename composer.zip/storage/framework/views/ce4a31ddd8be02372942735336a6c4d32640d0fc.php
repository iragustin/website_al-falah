<p class="mt-5 mb-3 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH D:\kuliah\kpkp-main\resources\views/auth/partials/copy.blade.php ENDPATH**/ ?>