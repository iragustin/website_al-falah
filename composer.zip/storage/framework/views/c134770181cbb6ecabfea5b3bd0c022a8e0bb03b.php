
<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            alert("<?php echo e(session('success')); ?>");
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>
    <section id="registration-form">
        <h2>UPLOAD BUKTI PEMBAYARAN</h2>
        <form action="/bukti-pembayaran" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Nama Lengkap Terdaftar:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="payment_proof">Upload Foto Bukti Pembayaran:</label>
                <input type="file" id="payment_proof" name="payment_proof" accept="image/*">
            </div>

            <button type="submit">KIRIM</button>
        </form>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/pendaftaranBukti.blade.php ENDPATH**/ ?>