<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(session('success')): ?>
        <script>
            alert("<?php echo e(session('success')); ?>");
        </script>
    <?php endif; ?>

    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>

    </div>

</body>

</html>
<?php /**PATH D:\kuliah\kpkp-main\resources\views/layouts/admin/layout.blade.php ENDPATH**/ ?>