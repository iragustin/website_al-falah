<?php $__env->startSection('content'); ?>
    <section id="news-page">
        <div class="berita-content">

            <div class="foto-berita">
                <img src="<?php echo e(asset('images/berita/' . $berita->image)); ?>" alt="Gambar Berita">
            </div>

            <div class="berita">
                <h1><?php echo e($berita->title); ?></h1>
                <p class="author-berita">Oleh : <?php echo e($berita->author); ?></p>
                <div class="berita-isi"><?php echo $berita->content; ?></div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/berita.blade.php ENDPATH**/ ?>