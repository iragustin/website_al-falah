
<?php $__env->startSection('content'); ?>
<section id="pengasuh">
        <div class="pengasuh-content">

            <div class="pengasuh-content-kiri">
                <div class="card-container">
                    <!-- card-box 1 -->
                    <div class="card-box-pengasuh">
                        <img src="<?php echo e(asset('images/pengasuh/' . $pengasuh->image)); ?>" alt="Foto Pengasuh">
                    </div>             
                </div>
                <p>KETUA YAYASAN ASYAHIDIYAH PONDOK PESANTREN AL-QUR'AN AL-FALAH</p>  
            </div>

            <div class="biography">
                <h1><?php echo e($pengasuh->name); ?></h1>
                <p><?php echo e($pengasuh->description); ?></p>
            </div>

        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/pengasuh.blade.php ENDPATH**/ ?>