<div class="sidebar">
    <div class="logo">
        <a href="/controlpanel/admin">
            <img src="<?php echo e(asset('images/logo-perusahaan.png')); ?>" alt="Logo Pesantren XYZ" href="/admin">
        </a>
    </div>
    <ul class="navbar">
        <li><a href="/controlpanel/admin/jumlahsantri">Jumlah Santri</a></li>
        <li><a href="/controlpanel/admin/pengasuh">Data Pengasuh</a></li>
        <li><a href="/controlpanel/admin/info-pendaftaran">Info Pendaftaran</a></li>
        <li><a href="/controlpanel/admin/pendaftar">Pendaftar</a></li>
        <li><a href="/controlpanel/admin/berita">Berita</a></li>
        <li><a href="/controlpanel/admin/brosur">Brosur</a></li>
        <li><a href="/controlpanel/admin/ganti-password">Ganti Password</a></li>
        <li><a href="/controlpanel/admin/logout">Logout</a></li>
    </ul>
</div>
<?php /**PATH D:\kuliah\kpkp-main\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>