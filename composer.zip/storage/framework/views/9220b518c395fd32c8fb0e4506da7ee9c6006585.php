<?php $__env->startSection('content'); ?>

<div class="container-head">
    <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>

</div>
<!-- Tempatkan konten admin di sini -->


<div class="container">

    <h1>Berita</h1>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Judul</th>
                <th>Author</th>
                <th>Tanggal</th>
                <th>Isi Berita</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($b->id); ?></td>
                    <td><img style="width: auto; height: 100px;" src="<?php echo e(asset('images/berita/' . $b->image)); ?>"
                            alt="image"></td>
                    <td><?php echo e($b->title); ?></td>
                    <td><?php echo e($b->author); ?></td>
                    <td><?php echo e($b->date); ?></td>
                    <td><?php echo substr($b->content, 0, 100); ?>...</td>
                    <td>
                        <a href="/berita/<?php echo e($b->slug); ?>"  class="view-button"><button>Lihat</button></a>
                        <a href="/controlpanel/admin/berita/edit/<?php echo e($b->id); ?>"  class="edit-button"><button>Edit</button></a>
                        <a href="/controlpanel/admin/berita/hapus/<?php echo e($b->id); ?>"  class="delete-button"><button>Hapus</button></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="add-news-button">
        <a href="/controlpanel/admin/berita/tambah"><button>Tambah Berita</button></a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/adminBerita.blade.php ENDPATH**/ ?>