<?php $__env->startSection('content'); ?>
<div class="container-head">
    <h1>PANEL ADMIN PONDOK PESANTREN AL-QUR'AN AL-FALAH</h1>

</div>
<!-- Tempatkan konten admin di sini -->


<div class="container">    
    <h1>List Pendaftar</h1>
    <h4>Takhosus</h4>
    <div class="container-table">
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Jenis kelamin</th>
                <th>Tempat Lahir</th>
                <th>Tanggal Lahir</th>
                <th>No.Telp</th>
                <th>Nama Ibu</th>
                <th>Nama Ayah</th>
                <th>No. Telp Wali</th>
                <th>E-Mail</th>
                <th>Alamat</th>
                <th>Asal Sekolah</th>
                <th>Bukti Pembayaran</th>
                <th>Status Pembayaran</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $takhosus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($t->name); ?></td>
                    <td><?php echo e($t->gender); ?></td>
                    <td><?php echo e($t->birth_place); ?></td>
                    <td><?php echo e($t->birth_date); ?></td>
                    <td><?php echo e($t->phone); ?></td>
                    <td><?php echo e($t->mother_name); ?></td>
                    <td><?php echo e($t->father_name); ?></td>
                    <td><?php echo e($t->parent_phone); ?></td>
                    <td><?php echo e($t->email); ?></td>
                    <td><?php echo e($t->address); ?></td>
                    <td><?php echo e($t->school_origin); ?></td>
                    <td>
                        <?php if($t->payment_proof == null): ?> - <?php else: ?>
                        <img style="width: 100px; height: auto;" src="<?php echo e(asset('images/payment_proof/' . $t->payment_proof)); ?>" alt="image">
                        <?php endif; ?>
                    </td>
                    <td>
                    <?php if($t->is_paid == 1): ?>
                        <select id="is_paid" name="is_paid" style="color:white; background-color: #45a049">
                                    <?php if($t->is_paid == 1): ?>
                                    <option value="" selected disabled style="background-color: grey">Sudah Bayar</option>
                                    <option value="<?php echo e($t->id); ?>">Belum Bayar</option>
                                    <?php else: ?>
                                    <option value="" selected disabled style="background-color: grey">Belum Bayar</option>
                                    <option value="<?php echo e($t->id); ?>">Sudah Bayar</option>
                                    <?php endif; ?>
                        </select>
                        <?php else: ?>
                        <select id="is_paid" name="is_paid" style="color:white; background-color: rgba(128, 0, 0, 0.5)">
                                <?php if($t->is_paid == 1): ?>
                                <option value="" selected disabled style="background-color: grey">Sudah Bayar</option>
                                <option value="<?php echo e($t->id); ?>">Belum Bayar</option>
                                <?php else: ?>
                                <option value="" selected disabled style="background-color: grey">Belum Bayar</option>
                                <option value="<?php echo e($t->id); ?>">Sudah Bayar</option>
                                <?php endif; ?>
                        </select>
                        <?php endif; ?>    
                        
                    </td>
                    <td>
                        <a href="/controlpanel/admin/pendaftar/edit/<?php echo e($t->id); ?>" class="edit-button"><button>Edit</button></a>
                        <a href="/controlpanel/admin/pendaftar/hapus/<?php echo e($t->id); ?>" class="delete-button"><button>Hapus</button></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    </div>

    <h4>Tahfidz</h4>
    <div class="container-table">
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Jenis kelamin</th>
                <th>Tempat Lahir</th>
                <th>Tanggal Lahir</th>
                <th>No.Telp</th>
                <th>Nama Ibu</th>
                <th>Nama Ayah</th>
                <th>No. Telp Wali</th>
                <th>E-Mail</th>
                <th>Alamat</th>
                <th>Asal Sekolah</th>
                <th>Bukti Pembayaran</th>
                <th>Status Pembayaran</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tahfidz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($t->name); ?></td>
                    <td><?php echo e($t->gender); ?></td>
                    <td><?php echo e($t->birth_place); ?></td>
                    <td><?php echo e($t->birth_date); ?></td>
                    <td><?php echo e($t->phone); ?></td>
                    <td><?php echo e($t->mother_name); ?></td>
                    <td><?php echo e($t->father_name); ?></td>
                    <td><?php echo e($t->parent_phone); ?></td>
                    <td><?php echo e($t->email); ?></td>
                    <td><?php echo e($t->address); ?></td>
                    <td><?php echo e($t->school_origin); ?></td>
                    <td>
                        <?php if($t->payment_proof == null): ?> - <?php else: ?>
                        <img style="width: 100px; height: auto;" src="<?php echo e(asset('images/payment_proof/' . $t->payment_proof)); ?>" alt="image">
                        <?php endif; ?>
                    </td>
                    <td>
                    <?php if($t->is_paid == 1): ?>
                        <select id="is_paid" name="is_paid" style="color:white; background-color:#45a049">
                                    <?php if($t->is_paid == 1): ?>
                                    <option value="" selected disabled style="background-color: grey">Sudah Bayar</option>
                                    <option value="<?php echo e($t->id); ?>">Belum Bayar</option>
                                    <?php else: ?>
                                    <option value="" selected disabled style="background-color: grey">Belum Bayar</option>
                                    <option value="<?php echo e($t->id); ?>">Sudah Bayar</option>
                                    <?php endif; ?>
                        </select>
                        <?php else: ?>
                        <select id="is_paid" name="is_paid" style="color:white; background-color: rgba(128, 0, 0, 0.5)">
                                <?php if($t->is_paid == 1): ?>
                                <option value="" selected disabled style="background-color: grey">Sudah Bayar</option>
                                <option value="<?php echo e($t->id); ?>">Belum Bayar</option>
                                <?php else: ?>
                                <option value="" selected disabled style="background-color: grey">Belum Bayar</option>
                                <option value="<?php echo e($t->id); ?>">Sudah Bayar</option>
                                <?php endif; ?>
                        </select>
                        <?php endif; ?>    
                        
                    </td>
                    <td>
                        <a href="/controlpanel/admin/pendaftar/edit/<?php echo e($t->id); ?>" class="edit-button"><button >Edit</button></a>
                        <a href="/controlpanel/admin/pendaftar/hapus/<?php echo e($t->id); ?>" class="delete-button"><button >Hapus</button></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
    </div>

    <div class="row">
        <a href="/controlpanel/admin/pendaftar/export" class="add-news-button"><button>Export ke Excel</button></a>
        <a href="/controlpanel/admin/pendaftar/tambah"class="add-news-button"><button>Tambah Pendaftar</button></a>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('[id="is_paid"]').change(function() {
            window.location.href = '/controlpanel/admin/pendaftar/status/ ' + $(this).val();
        });
    });

    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\kpkp-main\resources\views/adminPendaftar.blade.php ENDPATH**/ ?>